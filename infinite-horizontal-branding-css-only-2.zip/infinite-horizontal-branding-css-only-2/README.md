# Infinite horizontal branding CSS Only 2

A Pen created on CodePen.io. Original URL: [https://codepen.io/ramzibach-the-styleful/pen/LYoYejb](https://codepen.io/ramzibach-the-styleful/pen/LYoYejb).

